import axios from "axios"

export const defineUser = {
    username: "ok",
    password: "ok"
}

export const initialUser = {
    username: "",
    password: ""
}

export const initialNotes = {
    title: "",
    description: ""
}

export const checkUser = (user) => {
    if (user?.username === defineUser?.username && user?.password === defineUser?.password) {
        return {
            isValidUser: true,
            authToken: "fdsfsd4546f4dsfsdf4sd56f4sd"
        }
    } else {
        return {
            isValidUser: false,
            authToken: ""
        }
    }
}

export const createNote = async (note) => {
    const response = await axios.post("https://crude-3dcf5-default-rtdb.firebaseio.com/crude.json", note)
    if (response?.status === 200) {
        return {
            isAdd: true,
            status: response?.status
        }
    } else {
        return {
            isAdd: false,
            status: response?.status
        }
    }
}

export const fetchNotes = async () => {
    const response = await axios.get("https://crude-3dcf5-default-rtdb.firebaseio.com/crude.json")
    if (response?.status === 200) {
        const notes = Object.values(response?.data)
        const notesKey = Object.keys(response?.data)

        notesKey?.map((element, index) => notes[index].id = element)

        return {
            isFetch: true,
            data: notes
        }
    } else {
        return {
            isFetch: false,
            data: []
        }
    }
}

export const updateData = async (updateNote) => {
    const response = await axios.put(`https://crude-3dcf5-default-rtdb.firebaseio.com/crude/${updateNote?.id}.json`, updateNote)
    if (response?.status === 200) {
        return {
            isAdd: true,
            status: response?.status
        }
    } else {
        return {
            isAdd: false,
            status: response?.status
        }
    }
}