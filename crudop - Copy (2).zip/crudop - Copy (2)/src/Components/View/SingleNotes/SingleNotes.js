import React from 'react'

const SingleNotes = () => {
  return (
    <div>
      
    </div>
  )
}

export default SingleNotes
