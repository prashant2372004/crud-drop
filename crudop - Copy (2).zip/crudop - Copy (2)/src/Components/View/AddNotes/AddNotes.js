import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { createNote, initialNotes } from '../../Config/Config';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const AddNotes = () => {

  const [show, setShow] = useState(false);
  const [notes, setNotes] = useState(initialNotes);
  const navigate = useNavigate()

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleChange = (e) => {
    setNotes({ ...notes, [e.target.name] : e.target.value })
  }

  const handleAddNote = async () => {
    if(notes?.title && notes?.description){
      const response = await createNote(notes)
      if(response?.isAdd){
        toast.success("Note Added")
        navigate("/notes")
      } else{
        toast.error("Error Found")
        console.log(response?.status);
      }
    } else {
      toast.error("Please Enter Valid Details")
    }
    handleClose()
    
  }

  return (
    <div className='container'>
      <div className="row py-5">
        <div className="col-12">
          <button className='btn btn-secondary px-5 py-2' onClick={handleShow}>Add Note</button>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Add New Note</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <form action="#" >
                <div className="form-floating mb-3">
                  <input type="text" className="form-control" id="floatingInput" placeholder="Enter Your Title" name='title' value={notes?.title} onChange={handleChange} />
                  <label htmlFor="floatingInput">Username</label>
                </div>
                <div className="form-floating mb-3">
                  <input type="text" className="form-control" id="floatingPassword" placeholder="Description" name='description' value={notes?.description} onChange={handleChange} />
                  <label htmlFor="floatingPassword">Password</label>
                </div>
                <div className="form-Button text-center">
                </div>
              </form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
              <Button variant="primary" onClick={handleAddNote}>
                Add Notes
              </Button>
            </Modal.Footer>
          </Modal>
        </div>
      </div>
    </div>
  )
}

export default AddNotes
