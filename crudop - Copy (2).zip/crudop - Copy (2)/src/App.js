import React, { Suspense } from 'react'
import "./App.css"
import { Route, Routes } from 'react-router-dom'
const Login = React.lazy(() => import("./Components/View/Login/Login"))
const AddNotes = React.lazy(() => import("./Components/View/AddNotes/AddNotes"))
const Notes = React.lazy(() => import("./Components/View/Notes/Notes"))
const SingleNote = React.lazy(() => import("./Components/View/SingleNotes/SingleNotes"))
const Loader = React.lazy(() => import("./Components/Global/Loader/Loader"))

const App = () => {
  return (
    <Suspense fallback={<Loader/>}>
      <Routes>
        <Route path='/' element={<Login/>}/>
        <Route path='/add-notes' element={<AddNotes/>}/>
        <Route path='/notes' element={<Notes/>}/>
        <Route path='/notes/:id' element={<SingleNote/>}/>
      </Routes>
    </Suspense>
  )
}

export default App;